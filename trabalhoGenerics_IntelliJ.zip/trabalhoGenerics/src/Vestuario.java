public class Vestuario extends Produto {
    private String tamanho;

    public Vestuario(String nome, double preco, String tamanho) {
        super(nome, preco);
        this.tamanho = tamanho;
    }

    public String getTamanho() {
        return tamanho;
    }

    @Override
    public String toString() {
        return "Vestuário: " + super.toString() + " - Tamanho: " + tamanho;
    }
}
