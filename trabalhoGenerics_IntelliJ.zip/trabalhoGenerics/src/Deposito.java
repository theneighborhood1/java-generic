import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Deposito<T extends Produto> {
    private String identificacao;
    private List<T> itens;

    public Deposito(String identificacao) {
        this.identificacao = identificacao;
        this.itens = new ArrayList<>();
    }

    public void armazenar(T item) {
        itens.add(item);
    }

    public Optional<T> retirar() {
        if (itens.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(itens.remove(itens.size() - 1));
    }

    public Optional<T> buscarPorNome(String nome) {
        for (T item : itens) {
            if (item.getNome().equalsIgnoreCase(nome)) {
                return Optional.of(item);
            }
        }
        return Optional.empty();
    }

    public static <T extends Produto> Optional<T> buscarPorNome(Deposito<T> deposito, String nome) {
        return deposito.buscarPorNome(nome);
    }

    public static <T extends Produto> void transferir(Deposito<? extends T> origem, Deposito<? super T> destino) {
        Optional<? extends T> itemRetirado = origem.retirar();
        while (itemRetirado.isPresent()) {
            destino.armazenar(itemRetirado.get());
            itemRetirado = origem.retirar();
        }
    }

    public static void listarConteudo(Deposito<?> deposito) {
        System.out.println("=== " + deposito.getIdentificacao() + " ===");
        if (deposito.estaVazio()) {
            System.out.println("  (Depósito vazio)");
            return;
        }
        for (Produto p : deposito.getItens()) {
            System.out.println("  - " + p);
        }
    }

    public String getIdentificacao() {
        return identificacao;
    }

    public List<T> getItens() {
        return itens;
    }

    public boolean estaVazio() {
        return itens.isEmpty();
    }
}
