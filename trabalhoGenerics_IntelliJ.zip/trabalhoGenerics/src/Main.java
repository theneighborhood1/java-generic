import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        Deposito<Eletronico> depEletronicos = new Deposito<>("Depósito de Eletrônicos");
        Deposito<Alimento> depAlimentos = new Deposito<>("Depósito de Alimentos");
        Deposito<Vestuario> depVestuario = new Deposito<>("Depósito de Vestuário");

        depEletronicos.armazenar(new Eletronico("Notebook Dell Inspiron", 4200.00, 12));
        depEletronicos.armazenar(new Eletronico("Monitor LG 24pol", 890.00, 24));

        depAlimentos.armazenar(new Alimento("Arroz Tipo 1 5kg", 28.50, "15/08/2027"));
        depAlimentos.armazenar(new Alimento("Café Torrado 500g", 19.90, "10/05/2027"));

        depVestuario.armazenar(new Vestuario("Camiseta Algodão", 59.90, "G"));
        depVestuario.armazenar(new Vestuario("Jaqueta Jeans", 189.90, "M"));

        // Tarefa 2.c: O compilador impede adicionar um Alimento no depósito de Eletrônicos:
        // depEletronicos.armazenar(new Alimento("Feijão Carioca 1kg", 8.90, "20/10/2027"));
        // Erro de compilação no IntelliJ / javac:
        // java: incompatible types: Alimento cannot be converted to Eletronico

        // Tipos que não herdam de Produto também são barrados pelo limite <T extends Produto>:
        // Deposito<String> depInvalido = new Deposito<>("Inválido");
        // java: type argument java.lang.String is not within bounds of type-variable T

        System.out.println("--- CONTEÚDO INICIAL DOS DEPÓSITOS ---");
        Deposito.listarConteudo(depEletronicos);
        Deposito.listarConteudo(depAlimentos);
        Deposito.listarConteudo(depVestuario);

        System.out.println("\n--- BUSCA POR NOME (MÉTODO GENÉRICO + OPTIONAL) ---");
        Optional<Eletronico> busca = Deposito.buscarPorNome(depEletronicos, "Notebook Dell Inspiron");
        busca.ifPresent(e -> System.out.println("Encontrado: " + e.getNome() + " | Garantia: " + e.getGarantiaMeses() + " meses"));

        System.out.println("\n--- RETIRADA DE ITEM SEM NECESSIDADE DE CAST ---");
        Optional<Eletronico> retirado = depEletronicos.retirar();
        if (retirado.isPresent()) {
            Eletronico item = retirado.get();
            System.out.println("Retirado com sucesso: " + item.getNome() + " (R$ " + item.getPreco() + ")");
        }

        System.out.println("\n--- TRANSFERÊNCIA COM WILDCARDS (REGRA PECS) ---");
        Deposito<Produto> depGeral = new Deposito<>("Depósito Geral de Expedição");
        Deposito.transferir(depEletronicos, depGeral);
        Deposito.transferir(depAlimentos, depGeral);

        Deposito.listarConteudo(depEletronicos);
        Deposito.listarConteudo(depGeral);
    }
}
