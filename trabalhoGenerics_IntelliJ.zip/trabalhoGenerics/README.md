# Trabalho III - Explorando o Poder da Reutilização com Generics em Java

Projeto prático da disciplina de **Programação Orientada a Objetos II** (Ciência da Computação - 4º Período), ministrada pelo Prof. Márcio Alves de Araújo.

## Objetivo do Projeto

Refatorar o sistema de armazenamento de depósitos de uma empresa de logística, substituindo o uso inseguro de coleções genéricas baseadas em `Object` por classes e métodos parametrizados com **Generics** (`<T extends Produto>`), `Optional<T>` e *wildcards* (`<?>`, `<? extends T>` e `<? super T>` seguindo a regra PECS).

## Estrutura de Arquivos

- `Produto.java`: Superclasse abstrata base para todos os itens armazenáveis.
- `Eletronico.java`: Subclasse de `Produto` com atributo de garantia em meses.
- `Alimento.java`: Subclasse de `Produto` com atributo de data de validade.
- `Vestuario.java`: Subclasse de `Produto` com atributo de tamanho.
- `Deposito.java`: Classe genérica `Deposito<T extends Produto>` com retorno em `Optional<T>`, busca por nome (`buscarPorNome`), listagem com *unbounded wildcard* (`listarConteudo(Deposito<?>)`) e transferência entre depósitos com *bounded wildcards* (`transferir(Deposito<? extends T>, Deposito<? super T>)`).
- `Main.java`: Classe principal com os testes de armazenamento, busca, retirada sem necessidade de *cast* explícito, transferência PECS e demonstração (comentada) do erro de compilação ao tentar inserir tipos incompatíveis.

## Versão do Java Utilizada

- **Java JDK 17** (compatível com JDK 11, 17, 21 ou superior).

## Como Compilar e Executar no IntelliJ IDEA

1. Abra o **IntelliJ IDEA** e selecione **File > Open...** (ou **New > Project from Existing Sources...**).
2. Selecione a pasta onde os arquivos `.java` estão salvos (ou coloque os arquivos dentro da pasta `src` de um projeto Java).
3. Verifique se o SDK do projeto está configurado para o **JDK 17** (ou superior) em **File > Project Structure > Project**.
4. No painel lateral do projeto, clique com o botão direito no arquivo `Main.java` e selecione **Run 'Main.main()'** (ou pressione `Shift + F10`).

## Como Compilar e Executar pelo Terminal (Opcional)

Na pasta onde estão os arquivos `.java`, execute:

```bash
javac *.java
java Main
```
